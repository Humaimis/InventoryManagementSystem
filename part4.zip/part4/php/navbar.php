<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="../index.html">Inventory Management System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="../index.html">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="../products.html">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="../stock.html">Categories</a></li>
                <li class="nav-item"><a class="nav-link" href="../addproduct.html">Add Product</a></li>
                <li class="nav-item"><a class="nav-link" href="../addcategory.html">Add Category</a></li>
                <li class="nav-item"><a class="nav-link" href="../questionnaire.html">Questionnaire</a></li>
                <li class="nav-item"><a class="nav-link" href="../calculate.html">Calculator</a></li>
                <li class="nav-item"><a class="nav-link" href="../funpage.html">Fun Page</a></li>
                <li class="nav-item"><a class="nav-link" href="../about.html">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="../contact.html">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link" href="../reports.html">Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="search.php">Search</a></li>
                <li class="nav-item"><a class="nav-link" href="manage_products.php">Manage DB</a></li>
            </ul>
        </div>
    </div>
</nav>
